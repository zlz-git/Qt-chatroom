#ifndef PRIVATECHAT_H
#define PRIVATECHAT_H

#include <QMainWindow>
#include<chatclient.h>
#include<QtNetwork>
extern chatclient*chat;
namespace Ui {
class privatechat;
}

class privatechat : public QMainWindow
{
    Q_OBJECT

public:
    explicit privatechat(QWidget *parent = nullptr);
    ~privatechat();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();
    void readyReadslot();

private:
    Ui::privatechat *ui;
    QTcpSocket*privatesocket;
    QString toname;
};

#endif // PRIVATECHAT_H
