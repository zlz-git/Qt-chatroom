﻿
#include "QtAnimatedTextEdit.h"

QtAnimatedTextEdit::QtAnimatedTextEdit(QWidget * e)
    : QTextEdit(e)
{

}

QtAnimatedTextEdit::~QtAnimatedTextEdit()
{
    QHash<QMovie*, QUrl>::const_iterator i;
    for (i = m_hasUrls.constBegin(); i != m_hasUrls.constEnd(); ++i)
    {
        delete i.key();
    }
}

void QtAnimatedTextEdit::addAnimation(
        const QUrl& url, const QString& fileName)
{
    //插入Html描述的图片
    insertHtml("<img src='" + url.toString() + "'/>");

    //判断是否是相同的图片
    if (m_lstUrls.contains(url))
    {
        return;
    }
    else
    {
        m_lstUrls.append(url);
    }

    //创建QMovie以显示Gif
    QMovie* movie = new QMovie(this);
    movie->setFileName(fileName);
    movie->setCacheMode(QMovie::CacheNone);

    m_hasUrls.insert(movie, url);

    //绑定帧切换信号槽
    connect(movie, SIGNAL(frameChanged(int)), this, SLOT(subAnimate(int)));
    movie->start();
}
void QtAnimatedTextEdit::subAnimate(int a)
{
    //使用QMovie中的当前帧替换掉富文本中的图片元素
    QMovie* movie = qobject_cast<QMovie*>(sender());
    document()->addResource(QTextDocument::ImageResource,
            m_hasUrls.value(movie), movie->currentPixmap());
    setLineWrapColumnOrWidth(lineWrapColumnOrWidth());
}
