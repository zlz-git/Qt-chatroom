#include "emoji.h"
#include "ui_emoji.h"
#include<QLabel>
#include<QMovie>
#include<chatclient.h>
#include<mainwindow.h>
extern chatclient*chat;
extern int emojiflag;
emoji::emoji(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::emoji)
{
    ui->setupUi(this);
    initemoji();
}

emoji::~emoji()
{
    delete ui;
}
void emoji::addemoji(QString filename){
int row=emojilist.size()/ui->tableWidget->columnCount();
int column=emojilist.size()%ui->tableWidget->columnCount();

QLabel *emoji=new QLabel;
emoji->setMargin(4);
QMovie*m=new QMovie(filename);
m->start();
m->setScaledSize(QSize(24,24));
emoji->setMovie(m);
ui->tableWidget->setCellWidget(row,column,emoji);
emojilist.push_back(filename);
}
void emoji::initemoji(){
    this->setWindowFlags(Qt::FramelessWindowHint|Qt::WindowStaysOnTopHint);
    ui->tableWidget->setFocusPolicy(Qt::NoFocus);
    QString path=":/qtemoji/QQexpression/%1.gif";
    for(int i=0;i<130;i++){
        addemoji(path.arg(i+1));
    }
}

void emoji::on_tableWidget_cellClicked(int row, int column)
{

selecteomji=QString::number(row*10+column+1);
emit select();
this->close();
emojiflag=0;

}
QString emoji::selected(){
    return selecteomji;
}
