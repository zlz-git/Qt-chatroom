#ifndef EMOJI_H
#define EMOJI_H

#include <QWidget>

namespace Ui {
class emoji;
}

class emoji : public QWidget
{
    Q_OBJECT

public:
    explicit emoji(QWidget *parent = nullptr);
    ~emoji();
    void addemoji(QString filename);
    void initemoji();
     QString selected();

signals:
    void select();

private slots:
    void on_tableWidget_cellClicked(int row, int column);

private:
    Ui::emoji *ui;
    QStringList emojilist;
    QString selecteomji;
};

#endif // EMOJI_H
