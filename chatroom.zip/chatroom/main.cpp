#include "mainwindow.h"
#include <QApplication>
#include"login.h"
#include"wating.h"
#include"regist.h"
#include"login.h"
#include<iostream>
#include<chatclient.h>
#include<emoji.h>
using namespace std;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);


    login l;
    l.show();
    return a.exec();
}

