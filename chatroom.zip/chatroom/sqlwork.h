#ifndef SQLWORK_H
#define SQLWORK_H

#include <QDialog>
#include<Qtsql/QSqlDatabase>
#include<qtsql/QSqlQuery>
#include<QtSql/QSqlQueryModel>

namespace Ui {
class sqlwork;
}

class sqlwork : public QDialog
{
    Q_OBJECT

public:
    explicit sqlwork(QWidget *parent = nullptr);
    ~sqlwork();
    void show_view();
    void clear_focus();

private slots:
    void on_create_sql_pushbutton_clicked();

    void on_save_pushbutton_clicked();

    void on_find_pushbutton_clicked();

    void on_delete_pushbutton_clicked();

    void on_change_pushbutton_clicked();

private:
    Ui::sqlwork *ui;
    QSqlDatabase db;
    QSqlQuery *query;
    QSqlQueryModel *model;
    QString name,sex,number;
    QString find;



};

#endif // SQLWORK_H
