#include "sqlwork.h"
#include "ui_sqlwork.h"
#include<QMessageBox>

sqlwork::sqlwork(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::sqlwork)
{
    ui->setupUi(this);
    model=new QSqlQueryModel;
   QPixmap bg=QPixmap(":/images/QQ图片20191104172737.png").scaled(this->size());
    QPalette palette;
   palette=this->palette();
   palette.setBrush(QPalette::Background,QBrush(bg));
   this->setPalette(palette);


}

sqlwork::~sqlwork()
{
    delete ui;
    db.close();
}

void sqlwork::on_create_sql_pushbutton_clicked()
{
    db=QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("student.db");
    bool ok=db.open();
    if(ok){
        QMessageBox::information(this,"Information","打开成功！",QMessageBox::Ok);
    }
    else{
        QMessageBox::information(this,"Information","打开失败！",QMessageBox::Ok);
    }
    query=new QSqlQuery(db);
    query->exec("create table student(name vchar primary key,sex vchar,number vchar)");
    show_view();
}
void sqlwork::show_view(){
    model->setQuery("select*from student");
    model->setHeaderData(0,Qt::Horizontal,tr("姓名"));
    model->setHeaderData(1,Qt::Horizontal,tr("性别"));
    model->setHeaderData(2,Qt::Horizontal,tr("学号"));
    ui->tableView->setModel(model);
}

void sqlwork::on_save_pushbutton_clicked()
{
    name=ui->name_lineEdit->text();
    sex=ui->sex_combox->currentText();
    number=ui->number_lineEdit->text();
    if(name.isEmpty()||sex.isEmpty()||number.isEmpty()){
        QMessageBox::warning(this,"信息不完整！","错误!");
        return;
    }
    QString insert;
    insert=QObject::tr("insert into student values('%1','%2','%3')").arg(name,sex,number);
    bool ok=query->exec(insert);
    if(ok){
        QMessageBox::information(this,"消息","保存成功");
    }
    else{
        QMessageBox::information(this,"消息","保存失败");
        return ;
    }
    show_view();
    clear_focus();

}

void sqlwork::clear_focus(){
    ui->name_lineEdit->clear();
    ui->number_lineEdit->clear();
    ui->name_lineEdit->setFocus();
}

void sqlwork::on_find_pushbutton_clicked()
{
find=ui->find_lineEdit->text();

query->exec("select*from student");

while(query->next()){
    QString inf0=query->value(0).toString();
    QString inf1=query->value(1).toString();
    QString inf2=query->value(2).toString();
    if((inf0==find)||(inf1==find)||(inf2==find)){
        ui->name_lineEdit->setText(inf0);
        ui->sex_combox->setCurrentText(inf1);
        ui->number_lineEdit->setText(inf2);
        return;
    }
}
QMessageBox::information(this,"没有找到","没有这个数据",QMessageBox::Ok);

}

void sqlwork::on_delete_pushbutton_clicked()
{
    QString dele;
    dele=ui->delete_lineEdit->text();

    query->exec("select*from student");

    QString insert;
    while(query->next()){
        QString inf0=query->value(0).toString();
        QString inf1=query->value(1).toString();
        QString inf2=query->value(2).toString();
        if((inf0==dele)||(inf1==dele)||(inf2==dele)){
            if(inf0==dele){
                insert=QObject::tr("delete from student where name='%1'").arg(dele);
            }
            if(inf1==dele){
                insert=QObject::tr("delete from student where sex='%1'").arg(dele);
            }
            if(inf2==dele){
                insert=QObject::tr("delete from student where number='%1").arg(dele);
            }
            bool ok= query->exec(insert);
            if(ok){
                QMessageBox::information(this,"删除成功","成功",QMessageBox::Ok);
            }
            else{
                QMessageBox::information(this,"删除失败","错误",QMessageBox::Ok);
            }
            show_view();
            return;
        }
    }
    QMessageBox::information(this,"删除失败","没有这个记录！",QMessageBox::Ok);
}

void sqlwork::on_change_pushbutton_clicked()
{
    ui->delete_lineEdit->setText(find);
    on_delete_pushbutton_clicked();
    on_save_pushbutton_clicked();
    ui->delete_lineEdit->clear();
}
