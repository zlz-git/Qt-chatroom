#include "wating.h"
#include "ui_wating.h"
#include<QMovie>
#include<QDebug>

wating::wating(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::wating)
{
    ui->setupUi(this);
    this->setWindowFlag(Qt::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground);
    movie=new QMovie(":/images/u=2024958236,1297348046&fm=26&gp=0.jpg.gif");
    movie->setScaledSize(QSize(200,150));

    ui->label->setMovie(movie);
    movie->start();

}

wating::~wating()
{
    delete ui;
    delete movie;
}
