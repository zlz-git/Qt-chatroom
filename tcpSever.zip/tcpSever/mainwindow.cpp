#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QtNetwork>
#include<QJsonObject>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    tcpserver=new QTcpServer(this);
    tcpserver->listen(QHostAddress::Any,8888);

    connect(tcpserver,SIGNAL(newConnection()),this,SLOT(connecttoclient()));
    connect(this,SIGNAL(clientlistchanged()),this,SLOT(clientlistchangedslot()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
QString str=ui->textEdit_2->toPlainText();
str="服务器通知："+str;
QJsonObject obj;
obj.insert("type","serverinfo");
obj.insert("data",str);
for(int i=0;i<mysockets.size();++i){
   mysockets[i]->socket->write(QJsonDocument(obj).toJson());
}
ui->textEdit_2->clear();
}

void MainWindow::on_pushButton_2_clicked()
{
    for(int i=0;i<mysockets.size();++i){
        mysockets[i]->socket->disconnectFromHost();
    }
    ui->textEdit->clear();
}

void MainWindow::connecttoclient(){

    tcpsocket=tcpserver->nextPendingConnection();
    connect(tcpsocket,SIGNAL(readyRead()),this,SLOT(readyReadslot()));
    connect(tcpsocket,SIGNAL(disconnected()),this,SLOT(disconnectedslot()));
    QString ip=tcpsocket->peerAddress().toString();
    int port=tcpsocket->peerPort();
    ui->textEdit->append(QString("[%1,%2]连接成功").arg(ip).arg(port));
   clieninfo*clientinfo=new clieninfo;
   clientinfo->clientname="";
   clientinfo->socket=tcpsocket;
   mysockets.append(clientinfo);
   QJsonObject obj;
   obj.insert("type","clientport");
   obj.insert("clientport",port);
   tcpsocket->write(QJsonDocument(obj).toJson());

}

void MainWindow::readyReadslot(){
    QTcpSocket*socket=(QTcpSocket*)sender();
    QByteArray data=socket->readAll();
    QJsonObject obj=QJsonDocument::fromJson(data).object();
    QString type=obj.value("type").toString();
    if(type=="logininfo"){
        handleLoginInfo(data);
    }
    else if(type=="allinfo"){
        handleAllInfo(data);
    }
    else if(type=="oneinfo"){
        handleOneInfo(data);
    }
    else  {
        return;
    }
}
void MainWindow::handleLoginInfo(const QByteArray&data){
    QJsonObject obj=QJsonDocument::fromJson(data).object();
    QString username=obj.value("user").toString();
    QString clienthostname=obj.value("hostname").toString();

    QTcpSocket* s=(QTcpSocket*)sender();
    for(int i=0;i<mysockets.size();++i){
        if(s==mysockets[i]->socket){
            mysockets[i]->clientname=username;
            mysockets[i]->clienthostname=clienthostname;
            mysockets[i]->port=s->peerPort();
            emit clientlistchanged();
        }
    }
}
void MainWindow::handleAllInfo(const QByteArray &data){
    for(int i=0;i<mysockets.size();++i){
        mysockets[i]->socket->write(data);
    }
}
void MainWindow::handleOneInfo(const QByteArray &data){
    QJsonObject obj=QJsonDocument::fromJson(data).object();
    QString toname=obj.value("to").toString();
    for(int i=0;i<mysockets.size();++i){
        if(toname==mysockets[i]->clientname){
            mysockets[i]->socket->write(data);
        }
    }
}
void MainWindow::disconnectedslot(){
    QTcpSocket* s=(QTcpSocket*)sender();
    for(int i=0;i<mysockets.size();++i){
        if(s==mysockets[i]->socket){
            delete mysockets[i];
            mysockets.removeAt(i);
            emit clientlistchanged();
        }
    }
}

void MainWindow::clientlistchangedslot(){
    QJsonObject obj;
    QString clientlistinfo;

    for(int i=0;i<mysockets.size();++i){
        QString str=tr("%1+%2,").arg(mysockets[i]->clientname).arg(mysockets[i]->clienthostname);

        clientlistinfo.append(str);

    }
    obj.insert("type","clientlistinfo");
    obj.insert("clientlistinfo",clientlistinfo);

    for(int j=0;j<mysockets.size();++j){

        mysockets[j]->socket->write(QJsonDocument(obj).toJson());

    }

}
