#ifndef CHATCLIENT_H
#define CHATCLIENT_H
#include<QMainWindow>
#include<QtNetwork>
#include<emoji.h>
namespace Ui {
class chatclient;
}

class chatclient:public QMainWindow{
    Q_OBJECT
 public:
    explicit chatclient(QWidget *parent = nullptr);
    ~chatclient();
    QString getip();

    void connecttoserver();

    void handleData(const QByteArray &data);
    void handleclientlist(const QByteArray &data);
    void handleAllInfo(const QByteArray &data);
    void  handleServerInfo(const QByteArray&data);
    void handleClientPort(const QByteArray&data);
    void handleOneInfo(const QByteArray&data);
    static QString pname;
    QTcpSocket* getsocket();


private slots:
   void disconnectedslot();
   void readyReadslot();
   void on_pushButton_clicked();
   void on_pushButton_2_clicked();
   void successcts();
   void timedispaly();
   void on_tableWidget_cellDoubleClicked(int row, int column);

   void on_pushButton_3_clicked();
   void emojislot();



private:
    Ui::chatclient*ui;
    int i;
    int falg;
    QTcpSocket*tcpsocket;
    emoji *emojibox;
    QHash<QMovie*,QUrl>emojihash;


};

#endif // CHATCLIENT_H
