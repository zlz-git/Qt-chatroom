﻿
#pragma once
#include <QTextEdit>
#include <QWidget>
#include <QMovie>
#include <QPushButton>
#include <QVBoxLayout>

class QtAnimatedTextEdit : public QTextEdit
{
    Q_OBJECT

public:
    QtAnimatedTextEdit(QWidget * p = 0);
    ~QtAnimatedTextEdit();
    void addAnimation(const QUrl& url, const QString& fileName);

private slots:
    void subAnimate(int);

private:
    QList<QUrl> m_lstUrls;
    QHash<QMovie*, QUrl> m_hasUrls;
};
