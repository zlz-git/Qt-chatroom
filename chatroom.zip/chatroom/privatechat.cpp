#include "privatechat.h"
#include "ui_privatechat.h"
#include<QTime>
#include<QJsonObject>
#include<login.h>
#include<QDebug>
extern QSet<QString>privateforms;
extern QString privateinfo;
privatechat::privatechat(QWidget *parent) :
    QMainWindow(parent,Qt::WindowTitleHint|Qt::CustomizeWindowHint),
    ui(new Ui::privatechat)
{
    ui->setupUi(this);
    this->setAttribute(Qt::WA_DeleteOnClose,true);
    toname=chatclient::pname;
    ui->label->setText(tr("私聊:%1").arg(toname));
    privatesocket=chat->getsocket();
    //qDebug()<<privateinfo.size();
    if(privateinfo.size()!=0){
        ui->textBrowser->append(privateinfo);
        privateinfo.clear();
    }
    connect(privatesocket,SIGNAL(readyRead()),this,SLOT(readyReadslot()));
}

privatechat::~privatechat()
{
    delete ui;
}

void privatechat::on_pushButton_2_clicked()
{
   privateforms.remove(toname);
   this->close();

}

void privatechat::on_pushButton_clicked()
{
    QString date=QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
    QString info=ui->textEdit->toPlainText();
    if(info.size()!=0){
    ui->textBrowser->append(tr("%1 <%2>:\n   %3").arg(login::username).arg(date).arg(info));
    QJsonObject obj;
    obj.insert("date",date);
    obj.insert("type","oneinfo");
    obj.insert("info",info);
    obj.insert("to",toname);
    obj.insert("from",login::username);
    privatesocket->write(QJsonDocument(obj).toJson());
    ui->textEdit->clear();
}
}
void privatechat::readyReadslot(){
    /*QByteArray data=privatesocket->readAll();
    qDebug()<<data<<"触发信号！";
    QJsonObject obj=QJsonDocument::fromJson(data).object();
    QString type=obj.value("type").toString();
    if(type=="oneinfo"){
        QString info=obj.value("info").toString();
        QString from=obj.value("from").toString();
        QString date=obj.value("date").toString();
        qDebug()<<info;
        ui->textBrowser->append(tr("%1 <%2>对你说：\n  %3").arg(from).arg(date).arg(info));
    }
    else return;*/
    if(privateinfo.split(" ")[0]==toname){
    ui->textBrowser->append(privateinfo);
    privateinfo.clear();
    }

}
