#include "login.h"
#include "ui_login.h"
#include<QtSql>
#include"qmessagebox.h"
#include"mainwindow.h"
#include"regist.h"
#include<iostream>
#include <QDebug>
#include<wating.h>
#include<QElapsedTimer>
using namespace std;

login::login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);
    QImage bg=QImage(":/images/timg.jpg").scaled(this->size());
    QPalette palette(this->palette());
    palette.setBrush(QPalette::Background,QBrush(bg));
    this->setPalette(palette);
    ui->lineEdit->setText("user1");
    ui->lineEdit_2->setText("user1");


}
QString login::username="";
login::~login()
{
    delete ui;
    delete w;

}

void sleep(int i){
    QElapsedTimer t;
    t.start();
    while(t.elapsed()<i){
        QCoreApplication::processEvents();
    }
}
void login::on_pushButton_clicked()
{
    wating *load=new wating(this);
    load->setWindowFlags(load->windowFlags()|Qt::WindowStaysOnTopHint);
     int x=this->width()/2-load->width()/2;
     int y=this->height()/2-load->height()/2;
   load->move(x,y);
    load->show();

      sleep(2000);

    QString user;
    QString pwd;
    user=ui->lineEdit->text();
    pwd=ui->lineEdit_2->text();
    if(user==""){QMessageBox::warning(this,"","用户名不能为空！");}
    else if(pwd==""){QMessageBox::warning(this,"","密码不能为空！");}
    else{

        QSqlDatabase db;
        if(QSqlDatabase::contains("qt_sql_default_connection")){db=QSqlDatabase::database("qt_sql_default_connection");}
        else{
            db=QSqlDatabase::addDatabase("QSQLITE");
        }
        db.setDatabaseName("users.db");
        db.open();
        QSqlQuery query(db);
        QString s=QString("select *from users where username='%1' and pwd='%2'").arg(user).arg(pwd);
        query.exec(s);
        if(query.first()){
           load->close();
          username=user;
          QMessageBox::information(this,"","登录成功！");
             this->close();
         w=new MainWindow;
         w->show();


        }
        else{
           load->close();

            QMessageBox::warning(this,"","用户名或密码错误！");
        }
        db.close();

    }
}
//QString login::username=login::getusername();
void login::on_pushButton_2_clicked()
{
    r=new regist;
    r->show();
}
