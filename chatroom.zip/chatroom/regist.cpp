#include "regist.h"
#include "ui_regist.h"
#include<QMessageBox>
#include<QtSql>


regist::regist(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::regist)
{
    ui->setupUi(this);
    ui->lineEdit->setPlaceholderText("请输入用户名");
    ui->lineEdit_2->setPlaceholderText("请输入密码");

}

regist::~regist()
{
    delete ui;
}

void regist::on_pushButton_clicked()
{
    QString user;
    QString pwd;
    user=ui->lineEdit->text();
    pwd=ui->lineEdit_2->text();
    if(user==""){QMessageBox::warning(this,"","用户名不能为空！");}
    else if(pwd==""){QMessageBox::warning(this,"","密码不能为空！");}
    else{
        QSqlDatabase db;
        if(QSqlDatabase::contains("qt_sql_default_connection")){db=QSqlDatabase::database("qt_sql_default_connection");}
        else{
            db=QSqlDatabase::addDatabase("QSQLITE");
        }
        db.setDatabaseName("users.db");
        db.open();
       QSqlQuery query(db);
       query.exec("create table users(username vchar primary key,pwd vchar)");
       QString i=QString("insert into users values('%1','%2')").arg(user).arg(pwd);
       QString s=QString("select*from users where username='%1'").arg(user);

        if(query.exec(s)&&query.first()){
           QMessageBox::warning(this,"","用户名重复！");
       }
        else if(query.exec(i)){
            QMessageBox::information(this,"","注册成功！");
            this->close();
        }

     db.close();
    }
}

void regist::on_pushButton_2_clicked()
{
    this->close();
}
