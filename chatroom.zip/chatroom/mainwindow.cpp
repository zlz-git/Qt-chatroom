#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"sqlwork.h"
#include<iostream>
#include<chatclient.h>
#include<QDebug>
#include<QMessageBox>
using namespace std;
 chatclient*chat=NULL;
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::on_actionac1_triggered(){
  sqlwork *dialog=new sqlwork(this);
   dialog->show();
}
int MainWindow::onlyone=0;
void MainWindow::on_pushButton_clicked()
{   if(onlyone==0){
    chat=new chatclient(this);
    chat->show();
    onlyone=1;
    }
    else{
        QMessageBox::information(this,"","请勿重复打开！");
    }
}
