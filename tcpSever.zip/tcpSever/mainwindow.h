#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<QtNetwork>

namespace Ui {
class MainWindow;
}
struct clieninfo{
    clieninfo* client;
    QString clientname;
    QTcpSocket*socket;
    QString clienthostname;
    int port;

};
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    QList<clieninfo*>mysockets;
    void handleLoginInfo(const QByteArray&data);
    void handleAllInfo(const QByteArray&data);
    void handleOneInfo(const QByteArray&data);

signals:
    void clientlistchanged();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();
    void connecttoclient();
    void readyReadslot();
    void disconnectedslot();
    void clientlistchangedslot();

private:
    Ui::MainWindow *ui;
    QTcpServer*tcpserver;
    QTcpSocket*tcpsocket;

};

#endif // MAINWINDOW_H
