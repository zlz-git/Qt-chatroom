#ifndef LOGIN_H
#define LOGIN_H

#include <QDialog>
#include"regist.h"
#include"mainwindow.h"

namespace Ui {
class login;
}

class login : public QDialog
{
    Q_OBJECT

public:
    explicit login(QWidget *parent = nullptr);
    ~login();
    static QString username;


private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::login *ui;
    QString temp;
    regist *r;
    MainWindow *w;
};

#endif // LOGIN_H
