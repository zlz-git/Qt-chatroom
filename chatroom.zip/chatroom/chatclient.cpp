#include "chatclient.h"
#include "ui_chatclient.h"
#include"login.h"
#include<QJsonObject>
#include<QJsonDocument>
#include<QMessageBox>
#include<mainwindow.h>
#include<privatechat.h>
#include<QMovie>
#include<QUrl>
QString sendmessage;
int emojiflag=0;
QSet<QString>privateforms;
QString privateinfo;
chatclient::chatclient(QWidget *parent) :
    QMainWindow(parent,Qt::WindowTitleHint|Qt::CustomizeWindowHint),
    ui(new Ui::chatclient)
{
    ui->setupUi(this);
    this->setAttribute(Qt::WA_DeleteOnClose,true);
    i=0;
    falg=0;
    QTimer*t=new QTimer(this);
    t->start(1000);
    connect(t,SIGNAL(timeout()),this,SLOT(timedispaly()));
    ui->intimelabel->setText(QTime::currentTime().toString());
    ui->userlabel->setText(login::username);
    ui->iplabel->setText(getip());
    ui->tableWidget->setColumnWidth(0,100);
    ui->tableWidget->setColumnWidth(1,200);
    connecttoserver();
}
chatclient::~chatclient()
{
    delete ui;
}
void chatclient::emojislot(){
QString temp=emojibox->selected();
ui->textEdit->addAnimation(QUrl(tr("qrc:/qtemoji/QQexpression/%1.gif").arg(temp)),tr(":/qtemoji/QQexpression/%1.gif").arg(temp));
}

QString chatclient::getip(){

    QString localname=QHostInfo::localHostName();
    QHostInfo info=QHostInfo::fromName(localname);
    for(QHostAddress address:info.addresses()){
        if(address.protocol()==QAbstractSocket::IPv4Protocol){
            return address.toString();
        }
    }
    return 0;
}

void chatclient::timedispaly(){
ui->timelabel->setText(QString::number(i++));
}

void chatclient::connecttoserver(){
    tcpsocket=new QTcpSocket(this);
    tcpsocket->connectToHost("127.0.0.1",8888);

    connect(tcpsocket,SIGNAL(connected()),this,SLOT(successcts()));
    connect(tcpsocket,SIGNAL(readyRead()),this,SLOT(readyReadslot()));
    connect(tcpsocket,SIGNAL(disconnected()),this,SLOT(disconnectedslot()));

}

void chatclient::disconnectedslot(){
    if(falg==0){
    QMessageBox::information(this,"","与服务器断开连接，请重新登录！");
    this->close();}

}
void chatclient::successcts(){
    ui->textBrowser->append("\t         服务器连接成功！");
    QJsonObject obj;
    obj.insert("type","logininfo");
    obj.insert("user",tr("%1").arg(login::username));
    obj.insert("hostname",QHostInfo::localHostName());
    tcpsocket->write(QJsonDocument(obj).toJson());


}
void chatclient::readyReadslot(){
    QByteArray data=tcpsocket->readAll();
    //qDebug()<<data;
    //套接字里面的内容读一次就会取出来 再读就是空的！
    //QByteArray test=tcpsocket->readAll();
    //qDebug()<<test;
    handleData(data);
}
void chatclient::handleData(const QByteArray &data){

    QJsonObject obj=QJsonDocument::fromJson(data).object();
    QString type=obj.value("type").toString();

    if(type=="clientlistinfo"){
        handleclientlist(data);
    }
    else if(type=="allinfo"){
        handleAllInfo(data);
    }
    else if(type=="serverinfo"){
        handleServerInfo(data);
    }
    else if(type=="clientport"){
        handleClientPort(data);
    }
    else if(type=="oneinfo"){
        handleOneInfo(data);
    }

}
void chatclient::handleOneInfo(const QByteArray &data){
    QJsonObject obj=QJsonDocument::fromJson(data).object();
    QString from=obj.value("from").toString();
    QString info=obj.value("info").toString();
    QString date=obj.value("date").toString();
    if(privateforms.contains(from))
    {privateinfo.append(tr("%1 <%2>对你说：\n  %3").arg(from).arg(date).arg(info));
    }
    else{privateinfo.append(tr("%1 <%2>对你说：\n  %3").arg(from).arg(date).arg(info));

        for(int i=0;i<ui->tableWidget->rowCount();++i){
            if(ui->tableWidget->item(i,0)->text()==from){
                on_tableWidget_cellDoubleClicked(i,0);
                break;
            }
        }
    }
}

void chatclient::handleClientPort(const QByteArray &data){

    QJsonObject obj=QJsonDocument::fromJson(data).object();

   int port=obj.value("clientport").toInt();

    ui->portlabel->setText(QString::number(port));
}
void chatclient::handleServerInfo(const QByteArray &data){
    QJsonObject obj=QJsonDocument::fromJson(data).object();
    QString info=obj.value("data").toString();
    if(info.size()!=0){
        ui->textBrowser->append(tr("\t     %1").arg(info));
    }
}
void chatclient::handleAllInfo(const QByteArray &data){
    QJsonObject obj=QJsonDocument::fromJson(data).object();
    QString name=obj.value("user").toString();
    QString date=obj.value("date").toString();
    QString info=obj.value("info").toString();
    if(info.size()!=0){

       QString str=tr("<body><font color=blue><b>%1</b></font>  <font color=blue>&lt;%2&gt;</font>:<br>&nbsp;&nbsp;%3</body>").arg(name).arg(date).arg(info);

        ui->textBrowser->append(str);

    }
}
void chatclient::handleclientlist(const QByteArray &data){
    QJsonObject obj=QJsonDocument::fromJson(data).object();
    QString info=obj.value("clientlistinfo").toString();
    info.remove(info.size()-1,1);
    QStringList infolist=info.split(',');
    ui->tableWidget->setRowCount(0);
    ui->tableWidget->clearContents();
    ui->tableWidget->setHorizontalHeaderLabels(QStringList({"用户名","主机名"}));
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    for(int i=0;i<infolist.size();++i){
        QStringList list2=infolist[i].split('+');

        ui->tableWidget->insertRow(i);
        ui->tableWidget->setItem(i,0,new QTableWidgetItem(list2[0]));
        ui->tableWidget->setItem(i,1,new QTableWidgetItem(list2[1]));
    }
}
void chatclient::on_pushButton_clicked()
{
    QString date=QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
    QJsonObject obj;
    //sendmessage
    obj.insert("type","allinfo");
    obj.insert("date",date);
    obj.insert("user",login::username);
    obj.insert("info",ui->textEdit->toHtml());
    tcpsocket->write(QJsonDocument(obj).toJson());
    ui->textEdit->clear();
}

void chatclient::on_pushButton_2_clicked()
{
    falg=1;
    tcpsocket->disconnectFromHost();
    MainWindow::onlyone=0;
   this->close();
    privateforms.clear();
}

QTcpSocket* chatclient::getsocket(){
    return tcpsocket;
}
QString chatclient::pname="";
void chatclient::on_tableWidget_cellDoubleClicked(int row, int column)
{
   pname=ui->tableWidget->item(row,0)->text();
   if(pname==login::username){
   QMessageBox::information(this,"","不能与自己私聊！");
   }
   else if(privateforms.contains(pname)){
       QMessageBox::information(this,"","请勿重复打开！");
   }
   else{
    privatechat* prichat=new privatechat(this);
    privateforms.insert(pname);
    prichat->show();
   }
}

void chatclient::on_pushButton_3_clicked()
{
    if(emojiflag==0){
        emojibox=new emoji(this);
         connect(emojibox,SIGNAL(select()),this,SLOT(emojislot()));
         int x=this->width()/4;
         int y=this->height()/2-emojibox->height()/2;
         emojibox->move(x,y);
        emojibox->show();
    emojiflag=1;
    }
    else{
        emojibox->close();
        emojiflag=0;
    }
}
